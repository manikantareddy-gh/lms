package cfg.cafe.com;

import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component
public class Beverages {
  private String name;
}