package cfg.cafe.com;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SpringBootApplication
public class CafeManagementApplication {

  public static void main(String[] args) {
    ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
    Customer customer = context.getBean(Customer.class);
    System.out.println("Customer: "+customer.getCustomerName());
    System.out.println("Beverage: "+customer.getBeverage().getName());
    
  }

}