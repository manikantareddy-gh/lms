package cfg.cafe.com;

import lombok.Data;

@Data
public class Customer {
  private int customerId;
  private String customerName;
  private Beverages beverage;

}