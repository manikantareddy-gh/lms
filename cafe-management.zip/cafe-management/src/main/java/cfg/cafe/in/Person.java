package cfg.cafe.in;

import lombok.Data;

@Data
public class Person {
	private int id;
	private String name;
	

}
