package cfg.cafe.in;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component("Food")
@Data
public class Food extends Menu {
	
}
