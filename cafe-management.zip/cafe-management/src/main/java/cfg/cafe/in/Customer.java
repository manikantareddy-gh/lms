package cfg.cafe.in;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component
public class Customer extends Person{
	private String  phonenumber;
	
	@Autowired
	private Beverages beverage;

}
