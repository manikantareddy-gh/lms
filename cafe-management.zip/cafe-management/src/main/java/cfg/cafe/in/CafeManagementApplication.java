package cfg.cafe.in;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class CafeManagementApplication {
	public static void main(String[] args) {
		ConfigurableApplicationContext context =  SpringApplication.run(CafeManagementApplication.class, args);
		Customer customer = context.getBean(Customer.class);
		customer.setId(1);
		customer.setName("bhagath");
		customer.setPhonenumber("7842841135");
		
		Menu menu = context.getBean(Beverages.class);
		menu.setName("cappuccino");
		menu.setId(125);
		menu.setPrice(250.00);
		
		
		Menu menu2 = context.getBean(Food.class);
		menu2.setId(22);
		menu2.setName("Pasta");
		menu2.setPrice(150.35);
		
		Beverages beverage = context.getBean(Beverages.class);
		beverage.setDiscount(20);
		
		System.out.println(customer.getMenu().getId());
		System.out.println(customer.getMenu().getName());
		System.out.println(customer.getMenu().getPrice());
		
		System.out.println(beverage.getDiscount());
		
		
		System.out.println(customer.getName());
		System.out.println(customer.getId());
		System.out.println(customer.getPhonenumber());
				
	}

}
