package cfg.cafe.in;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class CafeManagementApplication {
	public static void main(String[] args) {
		ConfigurableApplicationContext context =  SpringApplication.run(CafeManagementApplication.class, args);
		Customer customer = context.getBean(Customer.class);
		customer.setId(1);
		customer.setName("bhagath");
		customer.setPhonenumber("7842841135");
		
		Beverages bev = context.getBean(Beverages.class);
		bev.setName("cappuccino");
		
		
		System.out.println(customer.getName());
		System.out.println(customer.getId());
		System.out.println(customer.getPhonenumber());
		System.out.println(customer.getBeverage().getName());
				
	}

}
