package cfg.cafe.in;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class Menu {
		private String name;
		private double price;
		private int id;
}
