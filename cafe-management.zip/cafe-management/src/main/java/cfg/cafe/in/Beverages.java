package cfg.cafe.in;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component("Beverages")
@Data
public class Beverages  extends Menu{
	private double discount;
}
