package cfg.cafe.in;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class Beverages {
	private String name;

}
