package cfg.sp.super_market;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SuperMarketApplicationTests {

	@Test
	void contextLoads() {
	}

}
