package cfg.sp.super_market_xml;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SpringBootApplication
public class SuperMarketApplicationxml {
	public static void main(String[] args) {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		Product pro = context.getBean(Product.class);

		System.out.println("Company name: " + pro.getCompany().getName());
		System.out.println("Product id: " + pro.getProduct_id());
		System.out.println("Product name: " + pro.getProduct_name());
	}

}
