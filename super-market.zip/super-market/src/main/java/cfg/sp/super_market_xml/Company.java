package cfg.sp.super_market_xml;

import lombok.Data;

@Data
public class Company {
	private int id;
	private String name;

}
