package cfg.sp.super_market_xml;

import lombok.Data;

@Data
public class Product {
	private int product_id;
	private String product_name;
	private Company company;

}
