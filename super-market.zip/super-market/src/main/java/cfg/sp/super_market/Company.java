package cfg.sp.super_market;

import org.springframework.stereotype.Controller;

import lombok.Data;

@Controller
@Data
public class Company {
	private String name;

}
