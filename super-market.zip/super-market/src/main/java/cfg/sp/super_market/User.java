package cfg.sp.super_market;

import org.springframework.stereotype.Controller;

import lombok.Data;

@Controller
@Data
public class User {
	private int id;
	private String name;

}
