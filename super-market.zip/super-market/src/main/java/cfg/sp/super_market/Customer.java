package cfg.sp.super_market;

import org.springframework.stereotype.Controller;

import lombok.Data;

@Controller("customer")
@Data
public class Customer extends User{
	private long phonenumber;

}
