package cfg.sp.super_market;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class SuperMarketApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = SpringApplication.run(SuperMarketApplication.class, args);

		Company cmp = context.getBean(Company.class);
		cmp.setName("Parle");

		Product pro = context.getBean(Product.class);
		pro.setCompany(cmp);
		pro.setProduct_id(1);
		pro.setProduct_name("Parle-G");

		System.out.println("------> Details of the product <----------");
		System.out.println("Company name: " + pro.getCompany());
		System.out.println("Product id: " + pro.getProduct_id());
		System.out.println("Product name: " + pro.getProduct_name());
		
		System.out.println("----------> User details <----------");
		
		Customer cus = context.getBean(Customer.class);
		cus.setPhonenumber(995522152);
		User user1 = context.getBean(Customer.class);
		user1.setId(1);
		user1.setName("Manikanta");
		
		
		Seller sp = context.getBean(Seller.class);
		sp.setSalary(25000);
		User user2 = context.getBean(Seller.class);
		user2.setId(45);
		user2.setName("Bhagath");
		
		
		Product product = context.getBean(Product.class);
		System.out.println(product.getUser().getId());
		System.out.println(product.getUser().getName());
	
		
		

		
		

	}

}
