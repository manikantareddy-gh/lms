package cfg.sp.super_market;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;

import lombok.Data;

@Controller
@Data
public class Product{
	private int product_id;
	private String product_name;
	
	@Autowired
	private Company company;
	
	@Autowired
	@Qualifier("customer")
	private User user;

}
