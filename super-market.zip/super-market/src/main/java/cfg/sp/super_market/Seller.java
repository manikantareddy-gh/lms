package cfg.sp.super_market;

import org.springframework.stereotype.Controller;

import lombok.Data;

@Controller("seller")
@Data
public class Seller  extends User {
	private double salary;

}
